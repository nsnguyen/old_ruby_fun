require 'test_helper'

class PetsHelperTest < ActionView::TestCase
end
